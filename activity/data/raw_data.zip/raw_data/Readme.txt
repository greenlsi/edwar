.csv files in this archive are in the following format: The first
column is the time of the session expressed as unix timestamp in UTC.
The next columns are the data from the 3-axis accelerometer
sensor. The accelerometer is configured to measure acceleration in the
range [-2g, 2g]. Therefore, the unit in this file is 1/64g. Data from
x, y and z axis are respectively in second, third and fourth column.

The data is first classified into left and right hand, and then it is
sorted by activity. Finally, the data of each individual is ordered,
named by ACT20100xx, identifying the subject by the last digits.
